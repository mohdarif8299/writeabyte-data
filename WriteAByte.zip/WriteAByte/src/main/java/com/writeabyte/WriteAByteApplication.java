package com.writeabyte;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WriteAByteApplication {

	public static void main(String[] args) {
		SpringApplication.run(WriteAByteApplication.class, args);
	}

}
