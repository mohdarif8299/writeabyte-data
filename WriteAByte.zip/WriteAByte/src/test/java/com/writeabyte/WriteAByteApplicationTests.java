package com.writeabyte;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WriteAByteApplicationTests {

	@Test
	void contextLoads() {
	}

}
